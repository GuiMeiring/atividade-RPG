package RPG;

public class Personagem {

}
