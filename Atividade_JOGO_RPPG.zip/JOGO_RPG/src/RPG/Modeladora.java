package RPG;

import java.awt.geom.Area;

public class Modeladora {
	 Personagem personagem;
	 Arma arma;
	 Classe classe;
	 Raça raça; 

}
