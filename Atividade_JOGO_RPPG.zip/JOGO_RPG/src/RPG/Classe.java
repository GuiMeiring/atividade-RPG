package RPG;

public class Classe {

}
