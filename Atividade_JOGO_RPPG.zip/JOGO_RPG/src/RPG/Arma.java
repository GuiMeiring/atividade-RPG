package RPG;

public class Arma {

}
