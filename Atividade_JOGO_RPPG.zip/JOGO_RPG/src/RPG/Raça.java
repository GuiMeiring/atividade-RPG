package RPG;

public class Raça {

}
