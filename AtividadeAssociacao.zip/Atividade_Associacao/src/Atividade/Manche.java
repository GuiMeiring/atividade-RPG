package Atividade;

public class Manche {
	private String pilotoAutomatico;

	public Manche(String pilotoAutomatico) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Piloto automático: " + pilotoAutomatico;
	}
	

}
