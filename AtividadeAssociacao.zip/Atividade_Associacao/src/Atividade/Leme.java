package Atividade;

public class Leme {
	private int tamLem;

	public Leme(int tamLeme) {
		this.tamLem = tamLeme;
	}

	@Override
	public String toString() {
		return "Tamanho do leme: " + tamLem;
	}
	

}
