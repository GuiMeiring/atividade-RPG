package Atividade;

public class Asas {

	private String formato;

	public Asas(String formato) {
		this.formato=formato;
	}

	@Override
	public String toString() {
		return "Formato da Asa: " + formato;
	}
	
    
}
