package Atividade;

public class Banheiro {

}
